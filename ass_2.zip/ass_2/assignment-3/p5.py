class Shape:
    def __init__(self):
        # The Shape class constructor (no parameters)
        pass
    
    def area(self):
        # Default area method in the Shape class
        return 0

class Square(Shape):
    def __init__(self, length):
        # The Square class constructor, takes length as a parameter
        self.length = length
    
    def area(self):
        # Overriding the area method in the Square class to calculate the area of the square
        return self.length ** 2

# Example usage

# Create an instance of Shape
shape = Shape()
print("Area of shape:", shape.area())  # Output: 0 (default area for shape)

# Create an instance of Square with a side length of 5
square = Square(5)
print("Area of square:", square.area())  # Output: 25 (side length squared)
