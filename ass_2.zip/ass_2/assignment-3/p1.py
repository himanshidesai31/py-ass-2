from datetime import datetime

class Person:
    def __init__(self, name, country, date_of_birth):
        # Initialize the attributes
        self.name = name
        self.country = country
        self.date_of_birth = datetime.strptime(date_of_birth, '%Y-%m-%d')  # Convert the date string to a datetime object
    
    def calculate_age(self):
        # Get the current date
        today = datetime.today()
        
        # Calculate the age based on the date of birth and today's date
        age = today.year - self.date_of_birth.year
        
        # Adjust the age if the birthday hasn't occurred yet this year
        if today.month < self.date_of_birth.month or (today.month == self.date_of_birth.month and today.day < self.date_of_birth.day):
            age -= 1
        
        return age
    
    def __str__(self):
        return f"Name: {self.name}, Country: {self.country}, Date of Birth: {self.date_of_birth.strftime('%Y-%m-%d')}, Age: {self.calculate_age()}"

# Example usage
person = Person("John Doe", "USA", "1990-05-15")
print(person)

# Another example with a different date of birth
person2 = Person("Jane Smith", "UK", "1985-12-25")
print(person2)
