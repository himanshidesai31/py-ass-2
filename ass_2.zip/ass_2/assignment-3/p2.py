class Person:
    def __init__(self, name, country, dob):
        self.name = name
        self.country = country
        self.dob = dob
    
    def display(self):
        # Display details from the parent class
        print(f"Name: {self.name}")
        print(f"Country: {self.country}")
        print(f"Date of Birth: {self.dob}")
    
    def details(self):
        # This method can be overridden in the child class
        print("Person Details:")
        self.display()

class Employee(Person):
    def __init__(self, name, country, dob, employee_id, department):
        # Call the parent class constructor to initialize the inherited attributes
        super().__init__(name, country, dob)
        self.employee_id = employee_id
        self.department = department
    
    def display(self):
        # We override the parent class display method to include employee details
        print(f"Employee ID: {self.employee_id}")
        print(f"Department: {self.department}")
        # Call the parent class's display method to show the person's details
        super().display()

    def details(self):
        # Overriding the details method to add more specific information for an employee
        print("Employee Details:")
        self.display()

# Example usage
# Creating an instance of the Employee class
emp1 = Employee("John Doe", "USA", "1990-05-15", "E123", "Engineering")
emp1.details()  # This will call the overridden details method of Employee class

print()  # Just to separate the output

# Creating another instance of Employee
emp2 = Employee("Jane Smith", "UK", "1985-12-25", "E124", "HR")
emp2.details()  # This will also call the overridden details method
