class BankAccount:
    def __init__(self, account_number, balance=0):
        # Private attributes
        self.__account_number = account_number
        self.__balance = balance
    
    # Method to deposit money into the account
    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited: {amount} units")
        else:
            print("Deposit amount must be positive.")
    
    # Method to withdraw money from the account
    def withdraw(self, amount):
        if amount > 0:
            if self.__balance >= amount:
                self.__balance -= amount
                print(f"Withdrew: {amount} units")
            else:
                print("Insufficient balance.")
        else:
            print("Withdraw amount must be positive.")
    
    # Method to get the current balance
    def get_balance(self):
        return self.__balance
    
    # Method to get the account number (for demonstration purposes)
    def get_account_number(self):
        return self.__account_number

# Create an instance of the BankAccount class
account = BankAccount("123456789", 500)

# Demonstrate deposit, withdraw, and balance check
print("Initial balance:", account.get_balance())  # Check initial balance

account.deposit(200)  # Deposit money
print("Updated balance after deposit:", account.get_balance())  # Check updated balance

account.withdraw(100)  # Withdraw money
print("Updated balance after withdrawal:", account.get_balance())  # Check updated balance

account.withdraw(700)  # Attempt withdrawal with insufficient funds

# Account number can be accessed through a public method (for demonstration)
print("Account Number:", account.get_account_number())
