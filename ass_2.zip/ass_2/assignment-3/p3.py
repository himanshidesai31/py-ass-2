class Vehicle:
    def speed(self):
        # Default message for the Vehicle class
        return "The speed of the vehicle is unknown."

class Car(Vehicle):
    def speed(self):
        # Overriding the speed method for Car
        return "The car speed is 120 km/h."

class Bike(Vehicle):
    def speed(self):
        # Overriding the speed method for Bike
        return "The bike speed is 80 km/h."

class Train(Vehicle):
    def speed(self):
        # Overriding the speed method for Train
        return "The train speed is 200 km/h."

def show_speed(vehicle):
    # This function demonstrates polymorphism.
    # It will call the speed method of any Vehicle type passed to it.
    print(vehicle.speed())

# Example usage:

# Create instances of each subclass
car = Car()
bike = Bike()
train = Train()

# Demonstrate polymorphism by calling show_speed() for each vehicle
print("Showing speed for different vehicles:")
show_speed(car)  # Output: The car speed is 120 km/h.
show_speed(bike)  # Output: The bike speed is 80 km/h.
show_speed(train)  # Output: The train speed is 200 km/h.
