# matrix_operations.py

class MatrixOperations:
    def __init__(self, rows, cols, initial_values=None):
      
        self.rows = rows
        self.cols = cols
        if initial_values is None:
            self.matrix = [[0] * cols for _ in range(rows)]
        else:
            if len(initial_values) != rows or any(len(row) != cols for row in initial_values):
                raise ValueError("Initial values do not match the specified dimensions.")
            self.matrix = initial_values

    def print_matrix(self):
     
        print("Matrix:")
        for row in self.matrix:
            print(' '.join(map(str, row)))

    def add(self, other):
      
        if self.rows != other.rows or self.cols != other.cols:
            raise ValueError("Matrices must have the same dimensions for addition.")
        
        result = [
            [self.matrix[i][j] + other.matrix[i][j] for j in range(self.cols)]
            for i in range(self.rows)
        ]
        return MatrixOperations(self.rows, self.cols, result)

    def multiply(self, other):
       
        if self.cols != other.rows:
            raise ValueError("Number of columns in the first matrix must be equal to the number of rows in the second matrix.")
        
        result = [
            [sum(self.matrix[i][k] * other.matrix[k][j] for k in range(self.cols)) for j in range(other.cols)]
            for i in range(self.rows)
        ]
        return MatrixOperations(self.rows, other.cols, result)
