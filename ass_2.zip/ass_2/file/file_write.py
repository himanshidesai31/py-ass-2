
with open('example.txt', 'w') as file:
    file.write('Hello, Everyone\n')
    file.write('welcome to gujat vidhyapith ,this is the first example of file handling program.')
