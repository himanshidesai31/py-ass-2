
with open('fruits.txt', 'r') as file:
    fruits_list = file.readlines()


fruits_list = [fruit.strip() for fruit in fruits_list]
print(fruits_list)
