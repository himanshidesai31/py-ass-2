
with open('example.txt', 'a') as file:
    file.write('\nAppending a new line to the file.')
