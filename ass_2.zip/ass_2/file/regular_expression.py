import re

def validate_email(email):
  
    pattern = r'\w+@\w+'

 
    match = re.match(pattern, email)

    if match:
        print(f"Valid email format: {email}")
    else:
        print(f"Invalid email format: {email}")


emails_to_test = [
    "gvp@a"
   
]

for email in emails_to_test:
    validate_email(email)
    print()