def print_file_content(file_path):
    """Print the content of a file."""
    try:
        with open(file_path, "r") as file:
            content = file.read()
            print("File Content:\n")
            print(content)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"Error: {e}")


def copy_file(source_path, destination_path):
    """Copy content from source file to destination file."""
    try:
        with open(source_path, "r") as source_file:
            content = source_file.read()
        with open(destination_path, "w") as destination_file:
            destination_file.write(content)
        print(f"File copied from '{source_path}' to '{destination_path}' successfully.")
    except FileNotFoundError:
        print(f"Error: The source file '{source_path}' does not exist.")
    except Exception as e:
        print(f"Error: {e}")


def read_and_write_file(file_path):
    """Read content from a file, modify it, and write it back."""
    try:
        with open(file_path, "r") as file:
            content = file.readlines()
        
        print("Current File Content:")
        for line in content:
            print(line, end="")
        
        # Example modification: Add a line at the end of the file
        new_line = input("\nEnter a new line to add to the file: ")
        content.append(new_line + "\n")
        
        with open(file_path, "w") as file:
            file.writelines(content)
        print(f"Content updated successfully in '{file_path}'.")
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"Error: {e}")


# Main Menu for File Operations
def main():
    while True:
        print("\nFile Operations Menu:")
        print("1. Print File Content")
        print("2. Copy a File")
        print("3. Read and Write a File")
        print("4. Exit")
        
        choice = input("Enter your choice (1-4): ")
        if choice == "1":
            file_path = input("Enter the file path: ")
            print_file_content(file_path)
        elif choice == "2":
            source_path = input("Enter the source file path: ")
            destination_path = input("Enter the destination file path: ")
            copy_file(source_path, destination_path)
        elif choice == "3":
            file_path = input("Enter the file path: ")
            read_and_write_file(file_path)
        elif choice == "4":
            print("Exiting the program.")
            break
        else:
            print("Invalid choice! Please select a valid option.")


if __name__ == "__main__":
    main()
