import re

def find_phone_numbers(text):
    # Define a regular expression pattern to match phone numbers.
    # This pattern will match:
    # - Optional country code starting with a '+' followed by 1 to 4 digits (e.g., +1, +44).
    # - Optional area code in parentheses (e.g., (123)) or without it (e.g., 123).
    # - Numbers with hyphens, spaces, or no separators (e.g., 123-456-7890, 123 456 7890, or 1234567890).
    pattern = r'(\+?\d{1,4}[\s\-]?)?(\(?\d{1,4}\)?[\s\-]?)?\d{1,4}[\s\-]?\d{1,4}[\s\-]?\d{1,4}'
    
    # Use re.findall to extract all phone numbers that match the pattern
    phone_numbers = re.findall(pattern, text)
    
    # Clean up and format the numbers into a single string
    cleaned_numbers = [''.join(number).strip() for number in phone_numbers]
    
    # Filter out any empty strings (if any)
    return [num for num in cleaned_numbers if num]

# Example input text
text = """
Contact me at +1-234-567-8901 or 987 654 3210.
You can also try (123) 456-7890 or +44 789 654 3210.
Or reach me at 321-654-9870, (800) 555-1234, or 2345678901.
"""

# Find phone numbers from the text
phone_numbers = find_phone_numbers(text)

# Output the found phone numbers
print("Found phone numbers:", phone_numbers)
