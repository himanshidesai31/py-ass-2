import os
import json

# File to store friends' data
FILE_NAME = 'friends_data.txt'


# Helper function to read all friends' data from file
def readAll():
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, 'r') as f:
            return json.load(f)
    return []


# Helper function to save the updated list of friends to file
def saveAll(friends_list):
    with open(FILE_NAME, 'w') as f:
        json.dump(friends_list, f, indent=4)


# 1. Add a new friend
def add(name, phone, github):
    friends = readAll()
    new_friend = {'name': name, 'phone': phone, 'github': github}
    friends.append(new_friend)
    saveAll(friends)
    print(f"Added friend: {name}")


# 2. Remove a friend by name, phone, or github
def remove(name=None, phone=None, github=None):
    friends = readAll()
    friends_to_remove = [f for f in friends if (f['name'] == name or f['phone'] == phone or f['github'] == github)]
    if friends_to_remove:
        friends = [f for f in friends if not (f['name'] == name or f['phone'] == phone or f['github'] == github)]
        saveAll(friends)
        print(f"Removed friend: {friends_to_remove[0]['name']}")
    else:
        print("Friend not found.")


# 3. Update phone number of a friend
def updatePhone(name, phone):
    friends = readAll()
    friend_found = False
    for friend in friends:
        if friend['name'] == name:
            friend['phone'] = phone
            friend_found = True
            break
    if friend_found:
        saveAll(friends)
        print(f"Updated phone number for {name}.")
    else:
        print(f"Friend {name} not found.")


# 4. Update Github handle of a friend
def updateGithub(name, github):
    friends = readAll()
    friend_found = False
    for friend in friends:
        if friend['name'] == name:
            friend['github'] = github
            friend_found = True
            break
    if friend_found:
        saveAll(friends)
        print(f"Updated GitHub handle for {name}.")
    else:
        print(f"Friend {name} not found.")


# 5. Print information of a specific friend by name
def printByName(name):
    friends = readAll()
    friend_found = False
    for friend in friends:
        if friend['name'] == name:
            print(f"Friend: {friend['name']}, Phone: {friend['phone']}, GitHub: {friend['github']}")
            friend_found = True
            break
    if not friend_found:
        print(f"Friend {name} not found.")


# 6. Print information of all friends
def printAll():
    friends = readAll()
    if friends:
        for friend in friends:
            print(f"Friend: {friend['name']}, Phone: {friend['phone']}, GitHub: {friend['github']}")
    else:
        print("No friends available.")


# Main Function
if __name__ == '__main__':
    # Example usage
    add('Alice', '1234567890', 'alice_github')
    add('Bob', '0987654321', 'bob_github')
    printAll()
    printByName('Alice')
    updatePhone('Alice', '1112223333')
    updateGithub('Bob', 'bob_updated')
    remove(name='Alice')
    printAll()
