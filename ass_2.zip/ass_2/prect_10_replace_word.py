import re

def find_and_replace(file_path, old_word, new_word):
    """Find and replace all occurrences of a word in a file."""
    try:
        # Read the file content
        with open(file_path, "r") as file:
            content = file.read()

        # Replace all occurrences of the old word with the new word (case insensitive)
        updated_content = re.sub(fr'\b{old_word}\b', new_word, content, flags=re.IGNORECASE)

        # Write the updated content back to the same file
        with open(file_path, "w") as file:
            file.write(updated_content)

        print(f"All occurrences of '{old_word}' have been replaced with '{new_word}' in '{file_path}'.")
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"Error: {e}")


# Main function to execute the replacement
def main():
    file_path = input("Enter the file path: ").strip()
    old_word = "gujarat"
    new_word = "gujrat"

    find_and_replace(file_path, old_word, new_word)


if __name__ == "__main__":
    main()
