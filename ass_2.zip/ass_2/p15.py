import re

def find_email_addresses(text):
    # Define a regex pattern for matching email addresses
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    
    # Use re.findall to extract all email addresses from the text
    email_addresses = re.findall(email_pattern, text)
    
    return email_addresses

# Example input text containing email addresses
text = """
You can contact me at john.doe@example.com for further details.
For support, reach out to support@company.org or admin@company.org.
My personal email is jane_doe12345@domain.co.uk.
"""

# Find all email addresses from the text
email_addresses = find_email_addresses(text)

# Output the found email addresses
print("Found email addresses:", email_addresses)
