

from matrix_operations import MatrixOperations

def display_menu():
    print("\nMatrix Operations Menu")
    print("1. Initialize matrix")
    print("2. Print matrix")
    print("3. Add two matrices")
    print("4. Multiply two matrices")
    print("5. Exit")

def main():
    matrix1 = None
    matrix2 = None
    
    while True:
        display_menu()
        
        choice = input("Enter your choice (1-5): ")
        
        if choice == '1':
            rows = int(input("Enter number of rows: "))
            cols = int(input("Enter number of columns: "))
            print("Enter matrix values row by row (space-separated):")
            initial_values = []
            for _ in range(rows):
                row = list(map(float, input().split()))
                if len(row) != cols:
                    print("Error: Incorrect number of columns in the row.")
                    return
                initial_values.append(row)
            matrix1 = MatrixOperations(rows, cols, initial_values)
            print("Matrix initialized.")
        
        elif choice == '2':
            if matrix1 is None:
                print("Matrix not initialized.")
            else:
                matrix1.print_matrix()
        
        elif choice == '3':
            if matrix1 is None:
                print("First matrix not initialized.")
                continue
            
            print("Enter second matrix values row by row (space-separated):")
            rows = int(input("Enter number of rows: "))
            cols = int(input("Enter number of columns: "))
            initial_values = []
            for _ in range(rows):
                row = list(map(float, input().split()))
                if len(row) != cols:
                    print("Error: Incorrect number of columns in the row.")
                    return
                initial_values.append(row)
            matrix2 = MatrixOperations(rows, cols, initial_values)
            result = matrix1.add(matrix2)
            print("Result of addition:")
            result.print_matrix()
        
        elif choice == '4':
            if matrix1 is None:
                print("First matrix not initialized.")
                continue
            
            print("Enter second matrix values row by row (space-separated):")
            rows = int(input("Enter number of rows: "))
            cols = int(input("Enter number of columns: "))
            initial_values = []
            for _ in range(rows):
                row = list(map(float, input().split()))
                if len(row) != cols:
                    print("Error: Incorrect number of columns in the row.")
                    return
                initial_values.append(row)
            matrix2 = MatrixOperations(rows, cols, initial_values)
            result = matrix1.multiply(matrix2)
            print("Result of multiplication:")
            result.print_matrix()
        
        elif choice == '5':
            print("Exiting the program.")
            break
        
        else:
            print("Invalid choice. Please enter a number between 1 and 5.")

if __name__ == "__main__":
    main()
