from academic_record_manager import AcademicRecordManager

def display_menu():
    print("\nAcademic Record Menu")
    print("1. Add a course")
    print("2. Drop a course")
    print("3. Print academic record")
    print("4. Calculate CGPA")
    print("5. Exit")

def main():
    record = AcademicRecordManager()

    while True:
        display_menu()

        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            course_name = input("Enter course name: ")
            try:
                credits = float(input("Enter number of credits: "))
                points = float(input("Enter earned points: "))
                record.add_course(course_name, credits, points)
            except ValueError:
                print("Invalid input. Please enter numeric values for credits and points.")

        elif choice == '2':
            course_name = input("Enter course name to drop: ")
            record.drop_course(course_name)

        elif choice == '3':
            print("\nAcademic Record:")
            record.print_record()

        elif choice == '4':
            cgpa = record.calculate_cgpa()
            print(f"\nCurrent CGPA: {cgpa:.2f}")

        elif choice == '5':
            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please enter a number between 1 and 5.")

if __name__ == "__main__":
    main()
