class AcademicRecordManager:
    def __init__(self, file_path="academic_record.txt"):
        self.courses = []
        self.file_path = file_path
        self.load_record()

    def load_record(self):
        """Load the academic record from a file."""
        try:
            with open(self.file_path, "r") as file:
                for line in file:
                    line = line.strip()
                    if line:  # Skip empty lines
                        course_name, credits, points = line.split(",")
                        self.courses.append({
                            "name": course_name,
                            "credits": float(credits),
                            "points": float(points)
                        })
            if not self.courses:
                print("No courses found in the record file.")
        except FileNotFoundError:
            print(f"File '{self.file_path}' not found. Creating a new file with default data.")
            self.create_default_record()
        except Exception as e:
            print(f"Error loading record: {e}")

    def create_default_record(self):
        """Create a default record file with sample courses."""
        default_data = [
            {"name": "Math", "credits": 3, "points": 12},
            {"name": "Science", "credits": 4, "points": 14}
        ]
        with open(self.file_path, "w") as file:
            for course in default_data:
                file.write(f"{course['name']},{course['credits']},{course['points']}\n")
        print(f"Default academic record created at '{self.file_path}'.")
        self.load_record()

    def save_record(self):
        """Save the academic record to a file."""
        try:
            with open(self.file_path, "w") as file:
                for course in self.courses:
                    file.write(f"{course['name']},{course['credits']},{course['points']}\n")
            print(f"Academic record saved to '{self.file_path}'.")
        except Exception as e:
            print(f"Error saving record: {e}")

    def add_course(self, course_name, credits, points):
        """Add a course to the record."""
        self.courses.append({"name": course_name, "credits": credits, "points": points})
        print(f"Added course: {course_name} ({credits} credits, {points} points)")
        self.save_record()

    def drop_course(self, course_name):
        """Drop a course from the record."""
        course_found = False
        for course in self.courses:
            if course["name"].lower() == course_name.lower():
                self.courses.remove(course)
                course_found = True
                print(f"Dropped course: {course_name}")
                break
        if not course_found:
            print(f"Course '{course_name}' not found in the record.")
        self.save_record()

    def print_record(self):
        """Print the current academic record."""
        if not self.courses:
            print("No courses in the record.")
        else:
            for course in self.courses:
                print(f"{course['name']} - {course['credits']} credits, {course['points']} points")

    def calculate_cgpa(self):
        """Calculate the CGPA."""
        total_credits = sum(course["credits"] for course in self.courses)
        total_points = sum(course["points"] for course in self.courses)
        if total_credits == 0:
            return 0.0
        return total_points / total_credits
