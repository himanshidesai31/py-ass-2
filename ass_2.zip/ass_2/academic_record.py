# academic_record.py

class AcademicRecord:
    def __init__(self):
        self.courses = {}  

    def add_course(self, course_name, credits, points):
        """
        Add a new course with its credits and earned points.
        """
        if credits <= 0 or points < 0:
            print("Credits must be positive and points cannot be negative.")
            return
        self.courses[course_name] = {'credits': credits, 'points': points}
        print(f"Added course: {course_name} with {credits} credits and {points} points.")

    def drop_course(self, course_name):
        """
        Remove a course from the record.
        """
        if course_name in self.courses:
            del self.courses[course_name]
            print(f"Dropped course: {course_name}.")
        else:
            print(f"Course '{course_name}' not found.")

    def print_record(self):
        """
        Print the list of all courses with their credits and points.
        """
        if not self.courses:
            print("No courses available.")
            return
        
        print(f"{'Course':<20} {'Credits':<10} {'Points':<10}")
        for course, details in self.courses.items():
            print(f"{course:<20} {details['credits']:<10} {details['points']:<10}")

    def calculate_cgpa(self):
        """
        Calculate the CGPA (Cumulative Grade Point Average).
        """
        total_credits = 0
        total_points = 0
        for details in self.courses.values():
            total_credits += details['credits']
            total_points += details['points'] * details['credits']
        
        if total_credits == 0:
            return 0.0
        
        return total_points / total_credits
