# tic_tac_toe_package/main.py

from game import TicTacToe

if __name__ == "__main__":
    game = TicTacToe()
    game.play()
