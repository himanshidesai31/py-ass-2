# tic_tac_toe_package/game.py

class TicTacToe:
    def __init__(self):
        # Initialize the board
        self.board = [" " for _ in range(9)]
        self.current_player = "X"

    def display_board(self):
        print("\n")
        print(f"{self.board[0]} | {self.board[1]} | {self.board[2]}")
        print("--+---+--")
        print(f"{self.board[3]} | {self.board[4]} | {self.board[5]}")
        print("--+---+--")
        print(f"{self.board[6]} | {self.board[7]} | {self.board[8]}")
        print("\n")

    def check_winner(self, player):
        # Winning combinations
        win_combinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
            [0, 4, 8], [2, 4, 6]              # Diagonals
        ]
        for combo in win_combinations:
            if self.board[combo[0]] == self.board[combo[1]] == self.board[combo[2]] == player:
                return True
        return False

    def is_draw(self):
        return " " not in self.board

    def make_move(self, move):
        if move < 0 or move >= 9 or self.board[move] != " ":
            print("Invalid move! Try again.")
            return False
        self.board[move] = self.current_player
        return True

    def switch_player(self):
        self.current_player = "O" if self.current_player == "X" else "X"

    def play(self):
        print("Welcome to Tic Tac Toe!")
        self.display_board()

        while True:
            try:
                move = int(input(f"Player {self.current_player}, enter your move (1-9): ")) - 1
            except ValueError:
                print("Invalid input! Please enter a number between 1 and 9.")
                continue

            if self.make_move(move):
                self.display_board()

                if self.check_winner(self.current_player):
                    print(f"Player {self.current_player} wins!")
                    break
                if self.is_draw():
                    print("It's a draw!")
                    break

                self.switch_player()
