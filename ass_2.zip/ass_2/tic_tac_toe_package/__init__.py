# tic_tac_toe_package/__init__.py

from .game import TicTacToe
