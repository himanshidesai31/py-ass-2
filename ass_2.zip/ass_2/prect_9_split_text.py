def split_text_into_words(input_file):
    """Split text into words from the input file."""
    try:
        with open(input_file, "r") as file:
            content = file.read()
            words = content.split()  # Split text into words
            print(f"Words extracted from '{input_file}':")
            print(words)
            return words
    except FileNotFoundError:
        print(f"Error: The file '{input_file}' does not exist.")
        return []
    except Exception as e:
        print(f"Error: {e}")
        return []


def join_words_into_sentences(words, output_file):
    """Join words to form sentences and save them to the output file."""
    try:
        sentence = " ".join(words)  # Join words to form a sentence
        with open(output_file, "w") as file:
            file.write(sentence)  # Write the sentence to the output file
        print(f"Sentence written to '{output_file}':")
        print(sentence)
    except Exception as e:
        print(f"Error: {e}")


# Main function to perform the operations
def main():
    input_file = input("Enter the input file path: ")
    output_file = input("Enter the output file path: ")

    # Split text into words
    words = split_text_into_words(input_file)

    # If words are successfully extracted, join and save them
    if words:
        join_words_into_sentences(words, output_file)


if __name__ == "__main__":
    main()
